#include <stdio.h>
#include <conio.h>
#define x 50
main()
{
 int n, i;
 for (i = 1; i <= x;i++)
 {
     printf("\nDigite um valor inteiro: ");
     scanf("%d", &n);
     if ((n % 2) == 0)
        printf("\n%d e par", n);
     else    
        printf("\n%d e impar", n);    
 }
 getch();
}
