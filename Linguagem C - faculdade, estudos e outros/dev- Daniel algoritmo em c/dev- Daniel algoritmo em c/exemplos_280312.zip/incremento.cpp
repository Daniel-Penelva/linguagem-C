#include <stdio.h>
#include <conio.h>
main()
{
 int n = 3;
 printf("\n%d", n++);
 printf("\n%d", n);
 printf("\n%d", ++n);
 getch();
}
 
