#include<stdio.h>
#include<conio.h>
main()
{ 
   int x,z,y; //voce esqueceu o ;
   printf("Este programa calculao maior numero entre os tres"); //voce esqueceu o ;
   printf("Digite o primeiro numero:");
    scanf("%d", &x);
   printf("Digite o psegundo numero:");
    scanf("%d", &z); 
   printf("Digite o terceiro numero:");
    scanf("%d", &y);  
  // arrume os operadores l�gicos e relacionais.  Coloque tb parenteses agrupando os operandos
    if(x>z) & (x>y) & (z<>y) //veja os operadores relacionais e logicos q passei no quadro. && - E != diferen�a
    if(x>z) & (x>y)
       printf("o maior numero entre os tres:", x); // falta mostrar o especificador de tipos para imprimir. Veja os exemplos que dei em sala - Saida de resultado.
     
    else
      if(z>x) & (z>y) //operador logico incorreto. 
       printf(" o maior numero entre os tres:", z);
       
    else
     if(y>x) &(y>z)
      printf("o maior numero entre os tres:" ,y);
      
getch();
return 0: //nao tem : � ; Voce nao precisa colocar o return, ja que seu main nao pede retorno
}                
