#include<stdio.h>
#include<conio.h>
main()
{ 
      float Raio,area;
      printf("Digite o Raio:");
       scanf("%f", Raio); // falta o especificador de endereco. Veja seus outros scanf (outros programas)
       area=Pi*Raio^2; // que operador � esse? voce confunde Pascal com C. Procure na Internet como realizar a potencia (funcao).
      printf("\na area do circulo �:" area);// faltou separar a msg da variavel com virgula e o especificador de tipo dentro do printf. veja meus exemplos dados em sala.
getch();
return 0;
}       
      
