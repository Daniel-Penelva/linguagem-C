#include<stdio.h>
#include<conio.h>
main()
{ 
      float n1,n2,n3,MA;
      printf("Digite a primeira nota:");
       scanf("%f", &n1);
      printf("Digite a segunda nota:");
       scanf("%f", &n2);
      printf("Digite a terceira nota:");
       scanf("%f", &n3);
       MA=(float)(n1+n2+n3)/3;
       scanf("A media �: %2f", MA); //scanf como o printf??? Arrume-o
       
      if(MA<3.0)
         printf("\nReprovado");
      
      if((MA>=3.0) && (MA<7.0)) // nao existe espaco em branco entre o operador logico &&. Coloquei tb mais 1 parenteses agrupando a condicao
          printf("\nProva Final");
      
      if(MA>7.0)
         printf("\nAprovado"); //faltou o ;    
      
getch();
return 0;
}         
       
         
      
