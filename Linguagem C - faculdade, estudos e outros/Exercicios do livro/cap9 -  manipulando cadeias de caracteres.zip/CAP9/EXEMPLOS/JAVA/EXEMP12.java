public class EXEMP12
{
 public static void main (String[] args)
 {
  char letra= 'A';
  System.out.println("N�mero do caractere "+letra+" na tabela ASCII = "+((int)letra));
 }
}
