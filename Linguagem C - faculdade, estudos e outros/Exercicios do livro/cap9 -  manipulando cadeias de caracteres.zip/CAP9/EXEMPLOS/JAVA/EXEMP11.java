public class EXEMP11
{
 public static void main (String[] args)
 {
  int i = 66;
  System.out.println("Caractere representado na tabela ASCII pelo n�mero 66 = "+ ((char)i));
 }
}
