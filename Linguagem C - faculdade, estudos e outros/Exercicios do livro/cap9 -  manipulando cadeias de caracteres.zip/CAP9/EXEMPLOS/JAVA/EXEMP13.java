public class EXEMP13
{
 public static void main (String[] args)
 {
   char letra = 'F';
   System.out.println("Sucessor de F = " +((char)(letra+1)));
 }
}
