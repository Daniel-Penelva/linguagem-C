public class EXEMP15
{
 public static void main (String[] args)
 {
 	String texto = "livro de java";
	System.out.println("Cadeia de caracteres antes da convers�o = "+texto);
	System.out.println("Cadeia de caracteres depois da convers�o = "+texto.toUpperCase());
 }
}
