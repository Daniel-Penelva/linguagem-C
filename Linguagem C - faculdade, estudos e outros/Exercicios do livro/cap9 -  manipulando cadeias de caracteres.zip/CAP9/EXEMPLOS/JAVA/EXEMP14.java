public class EXEMP14
{
 public static void main (String[] args)
 {
  char letra = 'F';
  System.out.println("Antecessor de F = " +((char)(letra-1)));
 }
}
