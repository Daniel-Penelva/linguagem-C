public class EXEMP16
{
 public static void main (String[] args)
 {
   String texto = "LIVRO DE JAVA";
   System.out.println("Cadeia de caracteres antes da convers�o = "+texto);
   System.out.println("Cadeia de caracteres depois da convers�o = "+texto.toLowerCase());
 }
}
